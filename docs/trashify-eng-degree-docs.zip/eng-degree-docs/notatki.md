Podziałka w tabelce nazwy

Książki w jednej grupie jako rzeczy "twarde" bibliografii

Źródła www w osobnej

Im wincy punktorów tym lepij

Spojrzeć na "rubriksa" i zapoznać się z zasadami oceny

Marginesy i numeracja stron ma być lustrzana - Prawo/Lewo?

## Lustrzane marginesy

> have a look at the geometry package; in particular, you'll want to look at bindingoffset. also make sure that you are loading twoside into your documentclass (assuming it needs it)
> [Link](https://tex.stackexchange.com/questions/175117/latex-mirror-margins)
